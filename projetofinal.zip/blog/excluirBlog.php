<?php
include_once ("../servico/Autenticacao.php");
include_once ("../servico/Bd.php");

$id=$_GET["id"];

$sql = "delete from blog where id='$id' ";
$bd = new Bd();
$contador = $bd->exec($sql);

echo "<!doctype html>
<html>
    <head> <title> Excluindo registro </title></head>
    <body>

    <script>
        window.location.replace('https://marcelocarvalho.000webhostapp.com/projetofinal/blog/consultaBlog.php?exclusao=1');
    </script>
  
    </body>
</html>";

?>
