<?php
	include_once ("../servico/Autenticacao.php");
?>

<!doctype html>
<html lang="pt-br">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">

	<link rel="stylesheet" href="estiloblog.css">    

	<title>Cadastro de blog</title>
</head>
<body>
	  
	<div class="container">
	<header>
            <div class="row">
                <div class="col-8"><h1>Blog de Tecnologia</h1></div>
                <div class="col-4" id="usuario">Seja bem-vindo, 
                    <?php
                        echo "<strong>".$_SESSION['loginusuario']."</strong>!";
                    ?>
                </div>
            </div>
            <nav class="nav nav-pills flex-column flex-sm-row">
                <a class="flex-sm-fill text-sm-center nav-link" href="menu.php">Página principal</a>
                <a class="flex-sm-fill text-sm-center nav-link active" href="consultaBlog.php">Cadastro do blog</a>
                <a class="flex-sm-fill text-sm-center nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Cadastro de usuários</a>
              </nav>
        </header>
	
		<h1>Tela de consulta</h1>
		<hr>
		<?php
			if (isset($_GET['sucesso'])) {
				echo '<div class="alert alert-success" role="alert">
				O registro foi incluído/atualizado com sucesso!
			  </div>';
			}
			if (isset($_GET['exclusao'])) {
				echo '<div class="alert alert-warning" role="alert">
				O registro foi excluído com sucesso!
			  </div>';
			}
		?>
			
		<a class="btn btn-info" href="incluirBlog.php" role="button">Incluir</a>
		<br><br>
			
		<table id="example" class="display" style="width:100%">
			<thead>
				<tr>
					<th>ID</th>
					<th>Título</th>
					<th>Corpo</th>
					<th></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				
		<?php
			include_once("../servico/Bd.php");
			
			$bd = new Bd();
			
			$sql = "select * from blog";
			
			foreach ($bd->query($sql) as $row) {
				
				echo "<tr>";
				echo "<td>". $row['id'] . "</td>";
				echo "<td>" .$row['titulo'] . "</td>";
				echo "<td>" .$row['corpo'] . "</td>";
				echo "<td> <a href='alterarBlog.php?id=" .$row['id'] . "' > Alterar</a></td>";
				echo "<td> <a onclick='Pergunta(".$row['id'].")' href='#' > Excluir</a></td>";
				echo '</tr>';
			}
		
		?>
		
		<script>
			function Pergunta(id){
				if (confirm("Deseja realmente excluir o registro ?")) {
				window.location.replace("excluirBlog.php?id="+id);
				} 
			}
			
		</script>
		
			</tbody>
			<tfoot>
				<tr>
					<th>ID</th>
					<th>Título</th>
					<th>Corpo</th>
					<th></th>
					<th></th>
				</tr>
			</tfoot>
		</table>
		
	
	</div> <!--fim container -->
	<!-- Optional JavaScript; choose one of the two! -->

	<!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
	
	
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		} );
	</script>
	
  </body>
</html>