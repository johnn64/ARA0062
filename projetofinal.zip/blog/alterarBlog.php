<?php

include_once "../servico/Autenticacao.php";
include_once "../servico/Bd.php";

$id=$_GET["id"];
    
$bd = new Bd();
$sql = "select * from blog where id='$id'";

foreach ($bd->query($sql) as $row) {
$titulo =  $row['titulo'];
$corpo =  $row['corpo'];
}
?>

<!doctype html>
<html lang="pt-br">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">

    <link rel="stylesheet" href="estiloblog.css">    

    <title>Editar publicação do blog</title>
</head>
<body>
    
    <div class="container">
    <header>
            <div class="row">
                <div class="col-8"><h1>Blog de Tecnologia</h1></div>
                <div class="col-4" id="usuario">Seja bem-vindo, 
                    <?php
                        echo "<strong>".$_SESSION['loginusuario']."</strong>!";
                    ?>
                </div>
            </div>
            <nav class="nav nav-pills flex-column flex-sm-row">
                <a class="flex-sm-fill text-sm-center nav-link" href="menu.php">Página principal</a>
                <a class="flex-sm-fill text-sm-center nav-link" href="consultaBlog.php">Cadastro do blog</a>
                <a class="flex-sm-fill text-sm-center nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Cadastro de usuários</a>
              </nav>
        </header>
        <h1>Tela de alteração</h1>
        <hr><br><br>
        
        <form action="salvar.php">
            <div class="form-group">
            <label for="exampleInputEmail1">Titulo</label>
            <?php
                echo "<input type='hidden' name='id' value='$id' >";
                echo "<input type='text' name='titulo' class='form-control' value='$titulo'>";
            ?>
            </div>
            <div class="form-group">
            <label for="cCorpo">Corpo</label>
            <?php
            echo "<textarea class='form-control' id='cCorpo' name='corpo' rows='3'>$corpo</textarea>";
            ?>
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
            <a href="consultaBlog.php" id="btCancelar" class="btn btn-outline-primary">Cancelar</a>
        </form>

        
        <br><br>
    </div> <!-- container -->

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

</body>
</html>