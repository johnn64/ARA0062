<?php
	include_once ("../servico/Autenticacao.php");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="estiloblog.css">    
    <title>Incluir publicação no blog</title>
</head>
<body>
    <div class="container">
        <header>
            <div class="row">
                <div class="col-8"><h1>Blog de Tecnologia</h1></div>
                <div class="col-4" id="usuario">Seja bem-vindo, 
                    <?php
                        echo "<strong>".$_SESSION['loginusuario']."</strong>!";
                    ?>
                </div>
            </div>
            <nav class="nav nav-pills flex-column flex-sm-row">
                <a class="flex-sm-fill text-sm-center nav-link" href="menu.php">Página principal</a>
                <a class="flex-sm-fill text-sm-center nav-link" href="consultaBlog.php">Cadastro do blog</a>
                <a class="flex-sm-fill text-sm-center nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Cadastro de usuários</a>
              </nav>
        </header>
        <h1>Tela de inclusão</h1> <br><br>

        <form action="salvar.php">
            <div class="form-group">
                <label for="cTitulo">Título</label>
                <input type="text" class="form-control" id="cTitulo" name="titulo">
            </div>
            <div class="form-group">
                <label for="cCorpo">Corpo</label>
                <textarea class="form-control" id="cCorpo" rows="3" name="corpo"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Incluir</button>
            <a href="consultaBlog.php" id="btCancelar" class="btn btn-outline-primary">Cancelar</button>
        </form>
    </div>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</body>
</html>