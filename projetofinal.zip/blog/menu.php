<?php
	include_once ("../servico/Autenticacao.php");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="estiloblog.css">
    <title>Blog de Tecnologia</title>
</head>
<body>
    <div class="container">
        <header>
            <div class="row">
                <div class="col-8"><h1>Blog de Tecnologia</h1></div>
                <div class="col-4" id="usuario">Seja bem-vindo, 
                    <?php
                        echo "<strong>".$_SESSION['loginusuario']."</strong>!";
                    ?>
                </div>
            </div>
            <nav class="nav nav-pills flex-column flex-sm-row">
                <a class="flex-sm-fill text-sm-center nav-link active" href="menu.php">Página principal</a>
                <a class="flex-sm-fill text-sm-center nav-link" href="consultaBlog.php">Cadastro do blog</a>
                <a class="flex-sm-fill text-sm-center nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Cadastro de usuários</a>
              </nav>
        </header>
        <div class="container">
            <h1>Tela principal</h1>
            <hr><br>
            <div class="row">
                <?php
                    include_once("../servico/Bd.php");
                    $bd = new Bd();
                    $sql = "select * from blog";

                    foreach ($bd->query($sql) as $row) {
                        echo '<div class="col-sm">
                            <div class="card" style="width: 18rem;">
                                <div class="card-body">
                                    <h5 class="card-title">'.$row['titulo'].'</h5>
                                    <p class="card-text">'.substr($row['corpo'],0,100).' ...</p>
                                    <a href="#" class="card-link">Ler mais</a>
                                </div>
                            </div>
                        </div>';
                    }
                ?>  
            </div>
        </div>
    </div>
</body>
</html>

