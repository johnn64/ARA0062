<?php
include_once ("../servico/Autenticacao.php");
include_once ("../servico/Bd.php");

$titulo = $_GET["titulo"];
$corpo = $_GET["corpo"];

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $sql = "update blog set titulo='$titulo', corpo='$corpo' where id=$id";
} else {
    $sql = "insert into blog values (null, '$titulo', '$corpo')";
}

$bd = new Bd();
$contador = $bd->exec($sql);    //insert update e delete

echo "<!doctype html>
<html>
    <head> <title> Salvando inclusão/alteração </title></head>
    <body>

    <script>
        window.location.replace('https://marcelocarvalho.000webhostapp.com/projetofinal/blog/consultaBlog.php?sucesso=1');
    </script>
  
    </body>
</html>";
?>