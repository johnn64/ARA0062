<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  <title>Login</title>
  <style>
    form {
      /*background-color: cadetblue;*/
      max-width: 700px;
      margin: 70px auto;
      padding: 50px;
    }
    button {
      margin-bottom: 20px;
    }
  </style>
</head>
<body style="background-image: url(img/loginbg.png);">
  <div class="container" style="background-color: rgba(255,255,255,0.95);">
    <form action="verifica.php" method="POST">
      <h1>Faça seu login</h1><br>
      <div class="form-group">
        <label for="exampleInputEmail1">Usuário</label>
        <input type="text" class="form-control" id="exampleInputEmail1" name="usuario">
      </div>
      <div class="form-group">
        <label for="exampleInputPassword1">Senha</label>
        <input type="password" class="form-control" id="exampleInputPassword1" name="senha">
      </div>
        <button type="submit" class="btn btn-primary">Entrar</button>

        <?php

          if (isset($_GET['erro'])) {
            echo '<div class="alert alert-danger" role="alert">
              Os dados inseridos estão incorretos
              </div>';
          }
        ?>
    </form>

    
  </div>
</body>
</html>