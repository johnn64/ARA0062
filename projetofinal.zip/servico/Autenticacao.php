<?php
session_start();

if ( ! isset($_SESSION["autenticado"]) ){
    echo "
    <script>
    window.location.replace('https://marcelocarvalho.000webhostapp.com/projetofinal/login.php');
    </script>
    ";
    
}

?>