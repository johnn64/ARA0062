<?php

class Bd {

    private $conn;

    function __construct() {
        /* Connect to a MySQL database using driver invocation */
        
        $dsn = 'mysql:dbname=id14818813_usuarios;host=localhost';
        $user = 'id14818813_john';
        $password = 'e$1i}!qEkxR1{R38';

        try {
            $this->conn = new PDO($dsn, $user, $password);
        } catch (PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
    }

    function query($sql) {
        try {
            return $this->conn->query($sql);
        } catch (PDOException $e) {
            echo 'Query failed: ' . $e->getMessage();
        }
    }

    function exec($sql) {
        try {
            return $this->conn->exec($sql);
        } catch (PDOException $e) {
            echo 'Query failed: ' . $e->getMessage();
        }
    }
}
?>