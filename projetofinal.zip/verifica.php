<?php
session_start();

include_once ("servico/Bd.php");

$usuario = $_POST["usuario"];
$senha = $_POST["senha"];
$sql = "select * from usuario where usuario='$usuario' and senha='$senha'";

$bd = new Bd();

foreach ($bd->query($sql) as $row) {
    $_SESSION["autenticado"]=true;
    $_SESSION["idusuario"]=$row['id'];
    $_SESSION["loginusuario"]=$row['usuario'];

    $html ="
    <!doctype>
    <html>
        <head> <title> Página de verificação </title></head>
        <body>
    
           <script>
    window.location.replace('https://marcelocarvalho.000webhostapp.com/projetofinal/blog/menu.php');
           </script>
      
        </body>
    </html>
    
    ";
    echo $html;
    return;
}
    
session_destroy();
$html ="
<!doctype>
<html>
    <head> <title> Página de verificação </title></head>
    <body>

    <script>
        window.location.replace('https://marcelocarvalho.000webhostapp.com/projetofinal/login.php?erro=1');
    </script>
  
    </body>
</html>
";

echo $html;
?>